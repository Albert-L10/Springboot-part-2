package Model;

public @interface Entity {
}
