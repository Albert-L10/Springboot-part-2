package Service;

import Model.User;
import Repository.FakeRepoInterface;
import org.springframework.http.converter.json.GsonBuilderUtils;

public abstract class UserServiceImp implements UserService,FakeRepoInterface {

    User user;
    @Override
    public void insertUser(long id, String name, String surname) {


        user.setId(id);
        user.setName(name);
        user.setSurname(surname);

        System.out.println(user.getName()+" "+user.getSurname()+" [name] entered!");

    }

    @Override
    public void findUserById (long id) {
        user.setId(id);
        System.out.println("Hello "+user.getSurname());

    }

    @Override
    public void deleteUser(long id) {
       if( user.getId()==id);
        System.out.println(user.getName()+" "+user.getSurname()+" removed");

    }
}
